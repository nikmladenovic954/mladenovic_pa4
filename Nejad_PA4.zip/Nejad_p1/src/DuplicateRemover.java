import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class DuplicateRemover {
    //Problem 1 shall contain a public class called DuplicateRemover

    private Set<String> uniqueWords;  //instance variable
    //This method will take the file name as input and remove the duplicate words using the Set
    public void remove(String dataFile) throws FileNotFoundException {
        //DuplicateRemover shall contain a method called remove

        String word;
        uniqueWords = new HashSet<String>();
        Scanner sc=new Scanner(new File(dataFile));
        while(sc.hasNext())
        {
            word=sc.next();
            uniqueWords.add(word);
        }
        sc.close(); //done using scanner object


    }

    //This method will write the contents of Set to the ouytput file
    public void write(String outputFile) throws IOException {
        //instance method write
        File f;
        FileWriter flwrite = null;

        f = new File(outputFile);
//If file already exists then write data to the existing file
        if(f.exists()) {
            flwrite=new FileWriter(f,true);
            Iterator itr=uniqueWords.iterator();

            while(itr.hasNext())
            {
                String str=(String)itr.next();
                flwrite.write(str+"\n");
            }
            flwrite.close(); //close scanner object after

        }
        else
        {
//If no file already exists.Create new File
            f.createNewFile();
            flwrite=new FileWriter(f);
            Iterator itr=uniqueWords.iterator();

            while(itr.hasNext())
            {
                String str=(String)itr.next();
                flwrite.write(str+"\n");
            }
            flwrite.close(); //close scanner object
//            System.out.println("Printed Data to specified location");
        }

    }

}