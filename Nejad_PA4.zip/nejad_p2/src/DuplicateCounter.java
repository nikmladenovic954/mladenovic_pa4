/*
Mila Nejad
11/1/2019
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

public class DuplicateCounter {
    //Problem 2 shall contain a public class called DuplicateCounter
    private int wordCounter;

    private Map<String, Integer> countWords;

    public DuplicateCounter() {

        this.countWords = new HashMap<String, Integer>();
    }

    public void count(String dataFile) throws FileNotFoundException {
        //DuplicateCounter shall contain a method called count
        Scanner input = new Scanner(new File(dataFile));

        while (input.hasNext()) {
            String word = input.next();
            Integer count = countWords.get(word);
            wordCounter++;
            if (count != null) {
                //Increment count if not null
                count = count + 1;
            } else {
                //Else set count to 1
                count = 1;
            }
            countWords.put(word, count);
        }
        input.close(); //done using Scanner object

    }

    public void write(String outputFile) throws IOException
    {
        FileWriter flwrit=new FileWriter(new File(outputFile));
        for (Entry<String, Integer> entry : countWords.entrySet())
            flwrit.write(entry.getKey() + " " + entry.getValue()+"\n");

        flwrit.close(); //close scanner object

    }
}